<?php //include('../includes/dropdowns.php');?>
<link href='https://unpkg.com/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>

<link rel="stylesheet" href="../css/forms.css">

<nav class="navbar navbar-expand-md fixed-top mynav">
<a class="navbar-brand" href="index.php">Sugam Sanskritam</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarCollapse">
<ul class="navbar-nav ml-auto">
  <li class="nav-item ">
    <a class="nav-link" href="index.php">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="contactus.php">Contact Us</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="signin.php">Students Corner</a>
  </li>

</ul>
</nav>

</div>
