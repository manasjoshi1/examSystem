class db_paper
