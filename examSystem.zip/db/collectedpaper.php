<?php

$query='select * from collected_paper where c'




 ?>
